# Сhallenge TDD

Задание по TDD в рамках темы eXtreme Programming

## Запуск тестов в терминале

На PostfixBuilder:  
```bash
dotnet test --filter FullyQualifiedName~PostfixBuilderTest --logger "console;verbosity=detailed"
```


На PostfixCalculator:  
```bash
dotnet test --filter FullyQualifiedName~PostfixCalculatorTest --logger "console;verbosity=detailed"
```
